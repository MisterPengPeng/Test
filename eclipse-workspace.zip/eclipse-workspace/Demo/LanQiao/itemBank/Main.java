package itemBank;

public class Main {
	public static void main(String[] args) {
		String a = "adf";
		String b = new String("adf");
		System.out.println(a == b);
	}
}
