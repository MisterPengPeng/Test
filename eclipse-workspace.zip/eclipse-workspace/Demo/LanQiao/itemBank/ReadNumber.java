package itemBank;

public class ReadNumber {
	public static void main(String[] args) {

	}
}
