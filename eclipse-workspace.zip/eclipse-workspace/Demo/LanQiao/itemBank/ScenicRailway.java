//package itemBank;
//
//import java.util.Scanner;
//
//public class ScenicRailway {

//	
//	static int n;
//	static int m;
//	
//	public static void main(String[] args) {
//		Scanner in = new Scanner(System.in);
//		
//		n = in.nextInt();
//		m = in.nextInt();
//	}
//}
