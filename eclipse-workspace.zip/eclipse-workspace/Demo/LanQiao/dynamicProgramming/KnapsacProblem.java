package dynamicProgramming;

public class KnapsacProblem {
	public static void main(String[] args) {
//		int[][] data = new int[3][4];
	}
}
