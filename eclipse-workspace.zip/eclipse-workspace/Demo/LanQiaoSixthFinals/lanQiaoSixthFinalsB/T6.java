package lanQiaoSixthFinalsB;


public class T6 {
	public static void main(String[] args) {
		
	}
}
